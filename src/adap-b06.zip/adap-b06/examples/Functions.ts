export function calculateDuration1(distance: number, speed: number): number {
    return distance / speed;
}